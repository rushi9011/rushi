﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserApplication.Data;
using UserApplication.Models;

namespace UserApplication.Controllers
{
    public class LoginController : Controller
    {

        private readonly UserApplicationContext _context;

        public LoginController(UserApplicationContext context)
        {
            _context = context;
        }
        public IActionResult Login()
        {
            return View();
        }

        // POST: Users/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(User user)
        {
            if (ModelState["Username"].ValidationState == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid  &&
                ModelState["Password"].ValidationState == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid)
            {
              if (IsValidUser(user.Username, user.Password))
                    {
                        return RedirectToAction("Index", "Users");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Invalid username or password");
                        return View(user);
                    }              
            }
                 return View(user);
        }

        private bool IsValidUser(string username, string password)
        {
            bool isValidUser = false;
            var user = _context.User.FirstOrDefault(m => m.Username == username);
            if (user != null)
            {
                if (user.Password == password)
                {
                    isValidUser = true;
                }
            }
            return isValidUser;
        }
    }


}
