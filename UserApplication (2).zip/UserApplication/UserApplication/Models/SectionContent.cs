﻿namespace UserApplication.Models
{
    public class SectionContent
    {
        public int Id { get; set; }
        public string?  HeaderContent { get; set; }
        public string? FooterContent { get; set; }
        public string? LeftContent { get; set; }
        public string? RightContent { get; set; }
        public string? CenterContent { get; set; }

    }
}
