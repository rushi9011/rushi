﻿using System.ComponentModel.DataAnnotations;

namespace UserApplication.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string? Username { get; set; }
        [Required]
        public string? Password { get; set; }
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        [Compare("Password")]
        public string? ConfirmPassword { get; set; }
        public string? NameOfUser { get; set; }
    }
}

