using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UserApplication.Views.Users
{
    //public class LoginModel : PageModel
    //{
    //    public void OnGet()
    //    {
    //    }
    //}
}
