﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserApplication.Data;
using UserApplication.Models;

namespace UserApplication.Controllers
{
    public class LoginController : Controller
    {

        private readonly UserApplicationContext _context;

        public LoginController(UserApplicationContext context)
        {
            _context = context;
        }
        public IActionResult Login()
        {
            return View();
        }

        // POST: Users/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(User user)
        {
            if (ModelState.IsValid)
            {
                //if (user.Password == user.ConfirmedPassword)
                //{

                    if (IsValidUser(user.Username, user.Password))
                    {
                        //             HttpContext.Session.SetString("Username", user.Username);

                        //return RedirectToAction("Index", "Home");
                        return RedirectToAction("Index", "Users");
                    }
                    else
                    {
                        // Authentication failed, display an error message
                        ModelState.AddModelError(string.Empty, "Invalid username or password");
                        return View(user);
                    }
                //}
                //else
                //{ // Confirm Password  failed, display an error message
                //    ModelState.AddModelError(string.Empty, "Confirm Password doesn't match the Password Filed");
                //    return View(user);

                //}
            }

            // If ModelState is not valid, return to the login page with validation errors
            return View(user);
        }

        private bool IsValidUser(string username, string password)
        {
            bool isValidUser = false;
            var user = _context.User.FirstOrDefault(m => m.Username == username);
            if (user != null)
            {
                if (user.Password == password)
                {
                    isValidUser = true;
                }
            }
            return isValidUser;
        }
    }


}
