﻿using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using UserApplication.Data;
using UserApplication.Migrations;
using UserApplication.Models;
using PageSections = UserApplication.Models.PageSections;

namespace UserApplication.Controllers
{
    public class PageSectionController : Controller
    {


        private readonly UserApplicationContext _context;

        public PageSectionController(UserApplicationContext context)
        {
            _context = context;
        }

        // GET: Users
        public async Task<IActionResult> Index()
        {
            return _context.PageSection != null ?
                        View(await _context.PageSection.ToListAsync()) :
                        Problem("Entity set 'UserApplicationContext.User'  is null.");
        }

        // Action to display the form for creating a new page
        public IActionResult Create()
        {
            return View();
        }

        // Action to handle the creation of a new page
        [HttpPost]
        public IActionResult Create(PageSections page)
        {
            if (ModelState.IsValid)
            {
                _context.PageSection.Add(page);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            return View(page);
        }


        // Action to display the page editor
        public IActionResult Edit(int id)
        {
            PageSections page = _context.PageSection.Find(id);
            return View(page);
        }

        // Action to save the edited page to the database
        [HttpPost]
        public IActionResult Edit(PageSections page)
        {
            if (ModelState.IsValid)
            {
                _context.PageSection.Update(page);
                _context.SaveChanges();
                Publish(page.Id);
                return RedirectToAction("Index"); // Redirect to the page listing
            }
            return View(page);
        }

        // Action to publish the page to the file system
        public IActionResult Publish(int id)
        {
            PageSections page = _context.PageSection.Find(id);

            // Create an HTML file with the page content
            string htmlContent = $@"
       <!DOCTYPE html>
        <html lang=""en"">
        <head>
            <meta charset=""UTF-8"">
            <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
            <title>Your Page Title</title>
            <script src=""https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js""></script>
            <style>
                body {{
                    margin: 0;
                    padding: 0;
                    font-family: Arial, sans-serif;
                }}

                header, footer {{
                    background-color: #333;
                    color: white;
                    text-align: center;
                    padding: 20px;
                }}

                section {{
                    display: flex;
                    justify-content: space-between;
                }}

                aside {{
                    width: 10%;
                    background-color: #f2f2f2;
                    padding: 10px;
                }}

                main {{
                    flex: 1;
                    padding: 210px; /* Adjusted padding for better appearance */
                }}

                #htmlEditor {{
                    width: 100%;
                    height: 300px;
                }}
            </style>
        </head>
        <body>
            <header>

                <h1>{page.Header}</h1>
                 <div id=""htmlHeaderEditor"">
                        <!--Header Editor will be initialized here -->
                    </div>
                
            </header>

            <section>
                <aside>
                    <h2>{page.Left}</h2>
                    <div id=""htmlLeftEditor"" style=""align=""vertical"">
                        <!--Left Editor will be initialized here -->
                    </div>

                </aside>

                <main>
                    <h2>{page.Center}</h2>
                    <div id=""htmlEditor"">
                        <!--Center Editor will be initialized here -->
                    </div>
                    <!-- Add main content here -->
                </main>

                <aside>
                    <h2>{page.Right}</h2>
                    <div id=""htmlRihtEditor"">
                        <!--Right Editor will be initialized here -->
                    </div>
                    <!-- Add right sidebar content here -->
                </aside>
            </section>

            <footer>
                <p>{page.Footer}</p>
                <div id=""htmlFooterEditor"">
                        <!--Footer Editor will be initialized here -->
                    </div>
            </footer>

            <script>
                document.addEventListener('DOMContentLoaded', (event) => {{
                    ClassicEditor
                        .create(document.querySelector('#htmlEditor'))
                        .catch(error => {{
                            console.error(error);
                        }});
                }});


                document.addEventListener('DOMContentLoaded', (event) => {{
                    ClassicEditor
                        .create(document.querySelector('#htmlHeaderEditor'))
                        .catch(error => {{
                            console.error(error);
                        }});
                }});

                document.addEventListener('DOMContentLoaded', (event) => {{
                    ClassicEditor
                        .create(document.querySelector('#htmlLeftEditor'))
                        .catch(error => {{
                            console.error(error);
                        }});
                }});

               document.addEventListener('DOMContentLoaded', (event) => {{
                    ClassicEditor
                        .create(document.querySelector('#htmlRihtEditor'))
                        .catch(error => {{
                            console.error(error);
                        }});
                }});

             document.addEventListener('DOMContentLoaded', (event) => {{
                    ClassicEditor
                        .create(document.querySelector('#htmlFooterEditor'))
                        .catch(error => {{
                            console.error(error);
                        }});
                }});
            </script>
        </body>
        </html>";


            // Save the HTML content to a file (you might want to specify a unique file name)
            string filePath = $"wwwroot/pages/{id}.html";
            System.IO.File.WriteAllText(filePath, htmlContent);

            return RedirectToAction("Index"); // Redirect to the page listing
        }
    }
}




    //        private readonly UserApplicationContext _dbContext;

//        public PageSectionController(UserApplicationContext dbContext)
//        {
//            _dbContext = dbContext;
//        }

//        // Action to display the page editor
//        public IActionResult EditPage()
//        {
//            var sections = _dbContext.Sections.ToList();
//            return View(sections);
//        }

//        // Action to handle user input and save to the database
//        [HttpPost]
//        public IActionResult SaveSections(List<Section> sections)
//        {
//            foreach (var section in sections)
//            {
//                if (section.Id == 0)
//                {
//                    // New section, add to the database
//                    _dbContext.Sections.Add(section);
//                }
//                else
//                {
//                    // Existing section, update in the database
//                    _dbContext.Entry(section).State = EntityState.Modified;
//                }
//            }

//            _dbContext.SaveChanges();

//            return RedirectToAction("EditPage");
//        }

//        // Action to retrieve content from the database and generate HTML page
//        public IActionResult GeneratePage()
//        {
//            var sections = _dbContext.Sections.ToList();
//            var combinedContent = CombineSections(sections);

//            // Save combinedContent as an HTML file
//            SaveAsHtmlFile(combinedContent);

//            return RedirectToAction("EditPage");
//        }

//        // Action to publish the HTML page to a configured directory
//        public IActionResult PublishPage()
//        {
//            var combinedContent = CombineSections(_dbContext.Sections.ToList());

//            // Save combinedContent as an HTML file
//            var filePath = SaveAsHtmlFile(combinedContent);

//            // Configure the destination directory for publishing
//            var destinationDirectory = "C:\\PublishDirectory";

//            // Implement publishing logic - copy the file to the destination directory
//            try
//            {
//                var destinationFilePath = Path.Combine(destinationDirectory, "publishedPage.html");
//                System.IO.File.Copy(filePath, destinationFilePath, true);
//                ViewBag.PublishMessage = "Page published successfully!";
//            }
//            catch (Exception ex)
//            {
//                ViewBag.PublishMessage = $"Publishing failed: {ex.Message}";
//            }

//            return RedirectToAction("EditPage");
//        }

//        // Helper method to combine sections into HTML content
//        private string CombineSections(List<Section> sections)
//        {
//            var combinedContent = string.Join("", sections.Select(s => s.Content));
//            return combinedContent;
//        }

//        // Helper method to save HTML content as a file and return the file path
//        private string SaveAsHtmlFile(string content)
//        {
//            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "combinedPage.html");

//            using (var writer = new StreamWriter(filePath))
//            {
//                writer.Write(content);
//            }

//            return filePath;
//        }
//    }
//}


