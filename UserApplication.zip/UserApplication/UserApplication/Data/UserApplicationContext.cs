﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using UserApplication.Models;

namespace UserApplication.Data
{
    public class UserApplicationContext : DbContext
    {
        public UserApplicationContext (DbContextOptions<UserApplicationContext> options)
            : base(options)
        {
        }

        public DbSet<UserApplication.Models.User> User { get; set; } = default!;

    

        public DbSet<UserApplication.Models.PageSections> PageSection { get; set; } = default!;
        public DbSet<UserApplication.Models.Section> Sections { get; set; } = default!;
    }
}
