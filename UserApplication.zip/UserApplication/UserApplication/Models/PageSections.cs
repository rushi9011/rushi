﻿namespace UserApplication.Models
{
    public class PageSections
    {
        public int Id { get; set; }
        public string? Header { get; set; }
        public string? Footer { get; set; }
        public string? Left { get; set; }
        public string? Right { get; set; }
        public string? Center { get; set; }
    }
}
